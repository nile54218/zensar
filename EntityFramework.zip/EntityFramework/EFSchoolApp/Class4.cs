﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace EFSchoolApp
{
    class Class4
    {
        static void Main(string[] args)
        {
            StudentAddress sa = new StudentAddress()
            {
                StudentId=111,
                Address1 = "newyork",
                City = "newyork",
                State = "newyork",
                Student = new Student()
                {
                    StudentId = 111,
                    StudentName = "Maria",
                    StandardId = 8
                }
            };



            using (DBSchoolEntities dbcontext = new DBSchoolEntities())
            {
                dbcontext.Entry(sa).State = EntityState.Added;
                foreach (var entity in dbcontext.ChangeTracker.Entries())
                {
                    Console.WriteLine($"Entity Name:{entity.Entity.GetType().Name}\t State:{entity.State}");
                }
                dbcontext.SaveChanges();
            }

            Console.ReadLine();
        }
    }
}
