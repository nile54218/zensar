﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EFSchoolApp.BLL;

namespace EFSchoolApp
{
    class Program
    {
        static void Main(string[] args)
        {
            StandardBLL stdbll = new StandardBLL();
            Console.WriteLine("1 Enter 2 Delete 3 Update 4 View 5 ViewAll");
            int response = Convert.ToInt32(Console.ReadLine());
            switch (response)
            {
                case 1:
                    Standard std = new Standard()
                    {
                        StandardId = 8,
                        StandardName = "VIII",
                        Description = "Eight"
                    };
                    if (stdbll.SaveStandard(std))
                    {
                        Console.WriteLine("standard added successfully");
                    }
                    else
                    {
                        Console.WriteLine("Error..");

                    }

                    break;

                case 2:
                    if (stdbll.DeleteStandard())
                    {
                        Console.WriteLine("Standard deleted");
                    }
                    else
                    {
                        Console.WriteLine("Standard not deleted");
                    }
                    break;


                case 3:
                    Standard stdupdate = new Standard()
                    {
                        StandardId = 3,
                        StandardName = "4th",
                        Description = "fourth"
                    };
                    if (stdbll.UpdateStandard(stdupdate))
                    {
                        Console.WriteLine("standard information update");
                    }
                    else
                    {
                        Console.WriteLine("standard information not updated");
                    }
                    break;

                case 4:
                    Standard s = stdbll.ViewStandard(5);
                    if (s!=null)
                    {
                        Console.WriteLine($"ID={s.StandardId} Name={s.StandardName} Description={s.Description}");
                    }
                    else
                    {
                        Console.WriteLine("Standard not found");
                    }
                    break;

                case 5:
                    List<Standard> stdlist = new List<Standard>();
                    stdlist = stdbll.ViewAll();
                    foreach (var stand in stdlist)
                    {
                        Console.WriteLine($"ID={stand.StandardId} Name={stand.StandardName} Description={stand.Description}");
                    }
                    break;
                default:
                    break;
            }
            

            Console.ReadLine();
        }
    }
}
