﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFSchoolApp
{
    class Class1
    {
        static void Main(string[] args)
        {
            using (DBSchoolEntities dbcontext=new DBSchoolEntities())
            {
                //var std = (from s in dbcontext.Standards
                //          join st in dbcontext.Students on s.StandardId equals st.StandardId
                //          select new
                //          {
                //              s.StandardId,
                //              s.StandardName,
                //              st.StudentId,
                //              st.StudentName
                //          }).ToList();

                var std = dbcontext.Students.Include("Standard").Where(s=>s.StudentName=="Scott").ToList();

                foreach (var v in std)
                {
                    Console.WriteLine($"{v.StudentId}\t{v.StudentName}\t{v.Standard.StandardId}\t{v.Standard.StandardName}");
                }
                Console.ReadLine();
            }
        }
    }
}
