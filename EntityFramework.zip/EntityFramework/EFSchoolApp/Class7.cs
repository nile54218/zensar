﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Validation;

namespace EFSchoolApp
{
    class Class7
    {
        static void Main(string[] args)
        {
            Teacher t1 = new Teacher()
            {
                TeacherId=1,
                TeacherName="Harry",
                TeacherType=TeacherType.PartTime
            };


            try
            {
                Student std = new Student()
                {
                    StudentId = 0,
                    StudentName = ""
                };

                using (DBSchoolEntities dbcontext=new DBSchoolEntities())
                {
                    dbcontext.Students.Add(std);
                    dbcontext.SaveChanges();
                }
            }
            catch (DbEntityValidationException ex)
            {

                //foreach (DbEntityValidationResult results in ex.EntityValidationErrors)
                //{
                //    foreach (DbValidationError error in results.ValidationErrors)
                //    {
                //        Console.WriteLine($"Property:{error.PropertyName}\n{error.ErrorMessage}");
                //    }
                //}
                Console.WriteLine(ex.Message);
            }

            Console.ReadLine();
        }
    }
}
