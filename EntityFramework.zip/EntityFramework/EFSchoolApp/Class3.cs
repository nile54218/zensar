﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace EFSchoolApp
{
    class Class3
    {
        static void Main(string[] args)
        {
            Student std = new Student()
            {
                StudentId = 106,
                StudentName = "Chuck",
                StandardId = 9,
                Standard =new Standard()
                {
                    StandardId=9,
                    StandardName="IX",
                    Description="Ninth"
                }
            };



            using (DBSchoolEntities dbcontext=new DBSchoolEntities())
            {
                dbcontext.Entry(std).State = EntityState.Added;
                foreach (var entity in dbcontext.ChangeTracker.Entries())
                {
                    Console.WriteLine($"Entity Name:{entity.Entity.GetType().Name}\t State:{entity.State}");
                }
                dbcontext.SaveChanges();
            }

            Console.ReadLine();
        }
    }
}
