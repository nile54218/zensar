﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFSchoolApp
{
    class StudentBLL
    {
        public GetStudentById_Result GetStudent(int id)
        {
            GetStudentById_Result std = new GetStudentById_Result();
            try
            {
                using (DBSchoolEntities dbcontext=new DBSchoolEntities())
                {
                    var v = dbcontext.GetStudentById(id).First();
                    std = v;
                }
                return std;
            }
            catch (Exception ex)
            {

                return std;
            }
        }
    }
}
