﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFSchoolApp.BLL
{
    class StandardBLL
    {
        public bool SaveStandard(Standard std)
        {
            try
            {
                using (DBSchoolEntities dbcontext = new DBSchoolEntities())
                {

                    dbcontext.Standards.Add(std);
                    dbcontext.SaveChanges();
                    //dbcontext.Database.ExecuteSqlCommand("insert into Standard values(" + std.StandardId + ",'" +
                    //    std.StandardName + "','" + std.Description + "'");
                    //int no = dbcontext.SaveStandard(std.StandardId, std.StandardName, std.Description);
                }

                return true;
            } 
            catch (Exception ex)
            {

                return false;
            }
            
        }


        public bool DeleteStandard()
        {
            try
            {
                using (DBSchoolEntities dbcontext=new DBSchoolEntities())
                {
                    //var s = dbcontext.Standards.First<Standard>();
                    //var s = dbcontext.Standards.Find(2);
                    var s = dbcontext.Standards.First<Standard>(x => x.StandardId == 3);
                    dbcontext.Standards.Remove(s);
                    dbcontext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }


        public bool UpdateStandard(Standard std)
        {
            try
            {
                using (DBSchoolEntities dbcontext=new DBSchoolEntities())
                {
                    var s = dbcontext.Standards.Find(std.StandardId);
                    s.StandardName = std.StandardName;
                    s.Description = std.Description;
                    dbcontext.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {

                return false;
            }
        }


        public Standard ViewStandard(int id)
        {
            Standard std = new Standard();
            try
            {
                using (DBSchoolEntities dbcontext = new DBSchoolEntities())
                {
                    //var s = dbcontext.Standards.Where(x => x.StandardId == id).First();
                    //var s = from st in dbcontext.Standards where st.StandardId == id select st;
                    //std = s.First();
                    var s = dbcontext.Standards.SqlQuery("select * from Standard where StandardId=" + id + "").First();
                    std = s;
                }
                return std;
            }
            catch (Exception ex)
            {

                return std;
            }
        }


        public List<Standard> ViewAll()
        {
            List<Standard> stdlist = new List<Standard>();
            using (DBSchoolEntities dbcontext = new DBSchoolEntities())
            {
                var s = dbcontext.Standards.ToList();
                stdlist = s;
            }
            return stdlist;
        }
    }
}
