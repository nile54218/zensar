﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EFSchoolApp.BLL;

namespace EFSchoolApp
{
    class Class2
    {
        static void Main(string[] args)
        {
            StudentBLL stdbll = new StudentBLL();
            var v=stdbll.GetStudent(1);
            Console.WriteLine($"{v.StudentId}\t{v.StudentName}\t{v.StandardId}");
            Console.ReadLine();
        }
    }
}
