﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFSchoolApp
{
    class Class5
    {
        static void Main(string[] args)
        {
            List<Student> stdlist = new List<Student>() { 
                new Student() { StudentId = 113, StudentName = "Student113", StandardId = 9 },
                new Student() { StudentId = 114, StudentName = "Student114", StandardId = 9 },
                new Student() { StudentId = 115, StudentName = "Student115", StandardId = 9 }
                };

            using (DBSchoolEntities dbcontext=new DBSchoolEntities())
            {
                dbcontext.Students.AddRange(stdlist);
                dbcontext.SaveChanges();
            }

            Console.ReadLine();
        }
    }
}
