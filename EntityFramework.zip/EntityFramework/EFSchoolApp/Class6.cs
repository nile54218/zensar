﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFSchoolApp
{
    class Class6
    {
        static void Main(string[] args)
        {
            using (DBSchoolEntities dbcontext=new DBSchoolEntities())
            {
                var studentAndaddress = dbcontext.StudentViews.ToList();
                foreach (var v in studentAndaddress)
                {
                    Console.WriteLine($"{v.StudentId}\t{v.StudentName}\t{v.Address1}\t{v.City}");
                }
            }

            Console.ReadLine();
        }
    }
}
