﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EFEmpApp.BLL;

namespace EFEmpApp
{
    class Class2
    {
        static void Main(string[] args)
        {
            ViewEmpBLL vbll = new ViewEmpBLL();
            var v = vbll.GetEmployee(1);
            Console.WriteLine($"{v.EmpCode}\t{v.EmpName}\t{v.EmpGender}\t{v.EmpDepartment}\t{v.EmpDesignation}");
            Console.ReadLine();
        }
    }
}
