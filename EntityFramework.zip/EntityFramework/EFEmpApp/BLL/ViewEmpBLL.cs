﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFEmpApp
{
    class ViewEmpBLL
    {
        public ViewEmployee_Result GetEmployee(int id)
        {
            ViewEmployee_Result emp = new ViewEmployee_Result();
            try
            {
                
                using (EMPZensarEntities dbcontext = new EMPZensarEntities())
                {
                    var v = dbcontext.ViewEmployee(id).First();
                    emp = v;
                }
                return emp;
            }
            catch (Exception ex)
            {

                return emp;
            }
        }
    }
}
