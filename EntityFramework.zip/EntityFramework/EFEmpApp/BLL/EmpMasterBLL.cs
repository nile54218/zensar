﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFEmpApp.BLL
{
    class EmpMasterBLL
    {
        public bool saveEmployee(EmpMaster emp)
        {
            try
            {
                using (EMPZensarEntities DbContext=new EMPZensarEntities())
                {
                    DbContext.EmpMasters.Add(emp);
                    DbContext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }


        public bool DeleteEmployee()
        {
            try
            {
                using (EMPZensarEntities dbcontext=new EMPZensarEntities())
                {
                    var e = dbcontext.EmpMasters.First<EmpMaster>(x => x.EmpDepartment == "sales");
                    dbcontext.EmpMasters.Remove(e);
                    dbcontext.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {

                 return false;
            }
        }


        public bool UpdateStandard(EmpMaster emp)
        {
            try
            {
                using (EMPZensarEntities dbcontext = new EMPZensarEntities())
                {
                    var e = dbcontext.EmpMasters.Find(emp.EmpCode);
                    e.EmpName = emp.EmpName;
                    e.EmpGender = emp.EmpGender;
                    e.EmpDepartment = emp.EmpDepartment;
                    e.EmpDesignation = emp.EmpDesignation;
                    dbcontext.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {

                return false;
            }
        }


        public EmpMaster ViewEmployee(int id)
        {
            EmpMaster emp= new EmpMaster();
            try
            {
                using (EMPZensarEntities dbcontext = new EMPZensarEntities())
                {
                    //var s = dbcontext.Standards.Where(x => x.StandardId == id).First();
                    var s = from st in dbcontext.EmpMasters where st.EmpCode == id select st;
                    emp = s.First();
                }
                return emp;
            }
            catch (Exception ex)
            {

                return emp;
            }
        }


        public List<EmpMaster> ViewAll()
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            using (EMPZensarEntities dbcontext = new EMPZensarEntities())
            {
                var s = dbcontext.EmpMasters.Where(x => x.EmpDepartment == "hr").ToList();
                emplist = s;
            }
            return emplist;
        }
    }
}
