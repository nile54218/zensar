﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFEmpApp
{
    class Class1
    {
        static void Main(string[] args)
        {
            using (EMPZensarEntities dbcontext = new EMPZensarEntities())
            {
                var emp = dbcontext.SalaryInfoes.Include("EmpMaster").Where(s => s.EmpCode == 2).ToList();
                foreach (var temp in emp)
                {
                    Console.WriteLine($"{temp.EmpCode}\t{temp.EmpMaster.EmpName}\t{temp.EmpMaster.EmpDesignation}" +
                        $"\t{temp.DateOfSalary}\t{temp.NetSalary}");
                }
            }

            
            Console.ReadLine();
        }
    }
}
