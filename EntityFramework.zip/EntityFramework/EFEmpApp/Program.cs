﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EFEmpApp.BLL;

namespace EFEmpApp
{
    class Program
    {
        static void Main(string[] args)
        {

            EmpMasterBLL empbll = new EmpMasterBLL();
            Console.WriteLine("1 Enter 2 Delete 3 Update 4 View 5 ViewAll");
            int response = Convert.ToInt32(Console.ReadLine());

            switch (response)
            {
                case 1:
                    EmpMaster emp = new EmpMaster()
                    {
                        EmpCode = 201,
                        EmpName = "James",
                        EmpDob = Convert.ToDateTime("1998-05-01"),
                        EmpGender = "male",
                        EmpDepartment = "sales",
                        EmpDesignation = "manager"
                    };

                    if (empbll.saveEmployee(emp))
                    {
                        Console.WriteLine("employee saved successfully");
                    }
                    else
                    {
                        Console.WriteLine("error");
                    }
                    break;

                case 2:
                    if (empbll.DeleteEmployee())
                    {
                        Console.WriteLine("employee deleted");
                    }
                    else
                    {
                        Console.WriteLine("employee not deleted");
                    }
                    break;

                case 3:
                    EmpMaster emp1 = new EmpMaster()
                    {
                        EmpCode = 100,
                        EmpName = "Ana",
                        EmpDob = Convert.ToDateTime("1998-05-01"),
                        EmpGender = "female",
                        EmpDepartment = "hr",
                        EmpDesignation = "assistant"
                    };

                    if (empbll.UpdateStandard(emp1))
                    {
                        Console.WriteLine("employee information update");
                    }
                    else
                    {
                        Console.WriteLine("employee information not updated");
                    }
                    break;

                case 4:
                    EmpMaster emp2 = empbll.ViewEmployee(100);
                    if (emp2!=null)
                    {
                        Console.WriteLine($"EmpCode={emp2.EmpCode} EmpName={emp2.EmpName} EmpGender={emp2.EmpGender} EmpDepartment={emp2.EmpDepartment} EmpDesignation={emp2.EmpDesignation}");
                    }
                    else
                    {
                        Console.WriteLine("employee not found");
                    }
                    break;

                case 5:
                    List<EmpMaster> emplist = new List<EmpMaster>();
                    emplist = empbll.ViewAll();
                    foreach (var empl in emplist)
                    {
                        Console.WriteLine($"EmpCode={empl.EmpCode} EmpName={empl.EmpName} EmpGender={empl.EmpGender} EmpDepartment={empl.EmpDepartment} EmpDesignation={empl.EmpDesignation}");
                    }
                    break;
                default:
                    break;
            }
            
            Console.ReadLine();
        }
    }
}
