﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EmpApplication.EntityModel;

namespace EmpApplication.DAL
{
    class SalaryInfoDAL1
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlDataAdapter da;
        DataSet ds = new DataSet();

        public List<SalaryInfo> GetSalarySheets(int EmpCode)
        {
            List<SalaryInfo> sheetlist = new List<SalaryInfo>();

            try
            {
                da = new SqlDataAdapter("GetSalSheets", sqlcon);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@EmpCode", SqlDbType.Int).Value = EmpCode;
                ds.Reset();
                da.Fill(ds, "SalarySheets");

                if (ds.Tables["SalarySheets"].Rows.Count > 0)
                {

                    foreach (DataRow dtr in ds.Tables["SalarySheets"].Rows)
                    {
                        SalaryInfo sheet = new SalaryInfo();
                        sheet.SalarySheetNo = Convert.ToInt32(dtr["SalarySheetNo"]);
                        sheet.EmpCode = Convert.ToInt32(dtr["EmpCode"]);
                        sheet.DateOfSalary = Convert.ToDateTime(dtr["DateOfSalary"]);
                        sheet.Basic = Convert.ToDouble(dtr["Basic"]);
                        sheet.Hra = Convert.ToDouble(dtr["Hra"]);
                        sheet.Da = Convert.ToDouble(dtr["Da"]);
                        sheet.NetSalary = Convert.ToDouble(dtr["NetSalary"]);
                        sheetlist.Add(sheet);
                    }
                }

                return sheetlist;
            }
            catch (Exception ex)
            {

                return sheetlist;
            }
        }
    }
}
