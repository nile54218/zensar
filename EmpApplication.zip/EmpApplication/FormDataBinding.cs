﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmpApplication
{
    public partial class FormDataBinding : Form
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlDataAdapter da;
        DataSet ds = new DataSet();

        
        public FormDataBinding()
        {
            
        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            DataSet ds1 = new DataSet();
            try
            {
                ds1.Reset();
                da = new SqlDataAdapter("Select * from EmpMaster", sqlcon);
                da.Fill(ds1,"emp");
                dataGridView1.DataSource = ds1.Tables["emp"];
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
