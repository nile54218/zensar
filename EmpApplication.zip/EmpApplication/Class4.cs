﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpApplication
{
    class Class4
    {
        static void Main(string[] args)
        {
            Class3 c3 = new Class3();
            c3.CreateTables();
            c3.CreateConstraint(c3.dt.Columns[0],c3.dt1.Columns[0]);
            c3.AddRowsToTable1();
            c3.AddRowsToTable2();
            Console.ReadLine();
        }
    }
}
