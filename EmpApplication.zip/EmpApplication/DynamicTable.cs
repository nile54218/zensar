﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace EmpApplication
{
    class DynamicTable
    {
        DataTable dt = new DataTable("Student");
        DataSet ds = new DataSet("student information");

        public void CreateColumns()
        {

            DataColumn dc1 = new DataColumn("StudID", typeof(int));
            DataColumn dc2 = new DataColumn("StudName", typeof(string));
            DataColumn dc3 = new DataColumn("Email", typeof(string));
            
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);
            dt.PrimaryKey = new DataColumn[] { dc1 };
            ds.Tables.Add(dt);
        }


        public void CreateRows()
        {
            Console.WriteLine("how many records?");
            int rows = Convert.ToInt32(Console.ReadLine());
            DataRow[] dtrs = new DataRow[rows];

            for (int i = 0; i < rows; i++)
            {
                dtrs[i] = dt.NewRow();
                Console.WriteLine("enter student ID");
                int studid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter student name");
                string studname = Console.ReadLine();
                Console.WriteLine("enter student email");
                string studmail = Console.ReadLine();
                dtrs[i]["StudID"] = studid;
                dtrs[i]["StudName"] = studname;
                dtrs[i]["Email"] = studmail;
                dt.Rows.Add(dtrs[i]);
            }

            Console.WriteLine("Data rows created!");
        }


        public void Display()
        {
            foreach (DataRow row in dt.Rows)
            {
                Console.WriteLine($"{row["StudID"]}\t{row["StudName"]}\t{row["Email"]}");
            }
        }
        static void Main(string[] args)
        {
            DynamicTable dtable = new DynamicTable();
            dtable.CreateColumns();
            dtable.CreateRows();
            dtable.Display();
            Console.ReadLine();
        }

    }
}
