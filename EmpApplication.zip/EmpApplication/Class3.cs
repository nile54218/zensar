﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace EmpApplication
{
    class Class3
    {
        public DataSet ds = new DataSet("Employee Information");
        public DataTable dt = new DataTable("Emp");
        public DataTable dt1 = new DataTable("Salary");

        public void CreateTables()
        {
            #region DataColumns for employee
            DataColumn dc1 = new DataColumn("EmpCode", typeof(int));
            DataColumn dc2 = new DataColumn("EmpName", typeof(string));
            DataColumn dc3 = new DataColumn("Email", typeof(string));

            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);
            dt.PrimaryKey = new DataColumn[] { dc1 };
            UniqueConstraint unique = new UniqueConstraint(dc3);
            dt.Constraints.Add(unique);
            #endregion

            ds.Tables.Add(dt);

            #region DataColumns for salary

            
            DataColumn dc21 = new DataColumn("EmpCode", typeof(int));
            DataColumn dc22 = new DataColumn("Basic", typeof(double));

            dt1.Columns.Add(dc21);
            dt1.Columns.Add(dc22);
            #endregion

            ds.Tables.Add(dt1);
            
        }


        public void CreateConstraint(DataColumn column1,DataColumn column2)
        {
            ForeignKeyConstraint foreignkey = new ForeignKeyConstraint("FK_Salary_Emp",dt.Columns["EmpCode"], dt1.Columns["EmpCode"]);
            foreignkey.DeleteRule = Rule.Cascade;
            foreignkey.AcceptRejectRule = AcceptRejectRule.Cascade;
            ds.Tables["Salary"].Constraints.Add(foreignkey);
            ds.EnforceConstraints = true;
        }


        public void AddRowsToTable1()
        {
            DataRow dtr1 = dt.NewRow();
            dtr1["EmpCode"] = 101;
            dtr1["EmpName"] = "Scott";
            dtr1["Email"] = "scott@gmail.com";
            dt.Rows.Add(dtr1);
            DataRow dtr2 = dt.NewRow();
            dtr2["EmpCode"] = 100;
            dtr2["EmpName"] = "Tiger";
            dtr2["Email"] = "tiger@gmail.com";
            dt.Rows.Add(dtr2);
        }

        public void AddRowsToTable2()
        {
            DataRow dtr1 = dt1.NewRow();
            dtr1["EmpCode"] = 101;
            dtr1["Basic"] = 30000;

            DataRow dtr2 = dt1.NewRow();
            dtr2["EmpCode"] = 100;
            dtr2["Basic"] = 35000;

            dt1.Rows.Add(dtr1);
            dt1.Rows.Add(dtr2);

        }

    }
}
