﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BankingApp.EntityModel;

namespace BankingApp.DAL
{
    class BranchDAL
    {
        SqlConnection sqlcon = new SqlConnection(BankingApp.Properties.Settings1.Default.ConStr);
        SqlDataReader dr;
        SqlCommand cmd = new SqlCommand();

        SqlDataAdapter da;
        DataSet ds = new DataSet();

        public bool SaveBranch(Branch branch)
        {
            try
            {
                cmd.Connection = sqlcon;
                

                cmd.CommandText = "SaveBranch";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@address", SqlDbType.VarChar).Value = branch.Address;
                cmd.Parameters.Add("@city", SqlDbType.VarChar).Value = branch.City;
                cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = branch.Name;
                cmd.Parameters.Add("@state", SqlDbType.VarChar).Value = branch.State;
                cmd.Parameters.Add("@zipcode", SqlDbType.VarChar).Value = branch.ZipCode;
                
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public bool DeleteBranch(int branchid)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "DeleteBranch";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BranchId", SqlDbType.Int).Value = branchid;

                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
        }



        public bool UpdateBranch(Branch branch)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "UpdateBranch";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BranchId", SqlDbType.Int).Value = branch.BranchId;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = branch.Address;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = branch.City;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = branch.Name;
                cmd.Parameters.Add("@State", SqlDbType.VarChar).Value = branch.State;
                cmd.Parameters.Add("@Zipcode", SqlDbType.VarChar).Value = branch.ZipCode;

                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }



        public Branch ViewBranch(int branchid)
        {
            Branch branch2 = new Branch();
            try
            {
                ds.Reset();
                da = new SqlDataAdapter("ViewBranch", sqlcon);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@BranchId", SqlDbType.Int).Value = branchid;
                
                
                da.Fill(ds, "br");

                if (ds.Tables["br"].Rows.Count > 0)
                {
                    foreach (DataRow dtr in ds.Tables["br"].Rows)
                    {
                        
                        branch2.BranchId = Convert.ToInt32(dtr["branch_id"]);
                        branch2.Address = dtr["address"].ToString();
                        branch2.City = dtr["city"].ToString();
                        branch2.Name = dtr["name"].ToString();
                        branch2.State = dtr["state"].ToString();
                        branch2.ZipCode = dtr["zip_code"].ToString();
                    }
                }

                return branch2;

            }
            catch (SqlException ex)
            {

                return branch2;
            }
        }


        public List<Branch> ViewAllBranch()
        {

            List<Branch> branchlist = new List<Branch>();
            try
            {
                ds.Reset();
                da = new SqlDataAdapter("ViewAllBranch", sqlcon);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;

                da.Fill(ds, "br");

                if (ds.Tables["br"].Rows.Count > 0)
                {
                    foreach (DataRow dtr in ds.Tables["br"].Rows)
                    {
                        Branch branch2 = new Branch();
                        branch2.BranchId = Convert.ToInt32(dtr["branch_id"]);
                        branch2.Address = dtr["address"].ToString();
                        branch2.City = dtr["city"].ToString();
                        branch2.Name = dtr["name"].ToString();
                        branch2.State = dtr["state"].ToString();
                        branch2.ZipCode = dtr["zip_code"].ToString();
                        branchlist.Add(branch2);
                    }
                }

                return branchlist;

            }
            catch (SqlException ex)
            {

                return branchlist;
            }
        }

    }
}
