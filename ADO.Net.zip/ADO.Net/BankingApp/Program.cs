﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankingApp.DAL;
using BankingApp.EntityModel;


namespace BankingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            BranchDAL branchdal = new BranchDAL();
            Console.WriteLine("1 insert branch\t2 delete branch\t3 update branch\t4 view branch\t5 view all branch");
            Console.WriteLine("enter choice");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    
                    Console.WriteLine("enter branch address");
                    string address = Console.ReadLine();
                    Console.WriteLine("enter branch city");
                    string city = Console.ReadLine();
                    Console.WriteLine("enter branch name");
                    string name = Console.ReadLine();
                    Console.WriteLine("enter branch state");
                    string state = Console.ReadLine();
                    Console.WriteLine("enter branch zipcode");
                    string zipcode = Console.ReadLine();

                    Branch branch = new Branch()
                    {
                        Address = address,
                        City = city,
                        Name = name,
                        State = state,
                        ZipCode = zipcode
                    };

                    if (branchdal.SaveBranch(branch))
                    {
                        Console.WriteLine("branch saved successfully");
                    }
                    else
                    {
                        Console.WriteLine("error occurred");
                    }
                    break;

                case 2:
                    Console.WriteLine("enter branch id");
                    int branchid = Convert.ToInt32(Console.ReadLine());

                    if (branchdal.DeleteBranch(branchid))
                    {
                        Console.WriteLine("branch deleted successfully");
                    }
                    else
                    {
                        Console.WriteLine("error occurred");
                    }
                    break;

                case 3:
                    Console.WriteLine("enter branch id");
                    branchid = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("enter branch address");
                    address = Console.ReadLine();
                    Console.WriteLine("enter branch city");
                    city = Console.ReadLine();
                    Console.WriteLine("enter branch name");
                    name = Console.ReadLine();
                    Console.WriteLine("enter branch state");
                    state = Console.ReadLine();
                    Console.WriteLine("enter branch zipcode");
                    zipcode = Console.ReadLine();

                    Branch branch1 = new Branch()
                    {
                        BranchId=branchid,
                        Address = address,
                        City = city,
                        Name = name,
                        State = state,
                        ZipCode = zipcode
                    };

                    if (branchdal.UpdateBranch(branch1))
                    {
                        Console.WriteLine("branch updated successfully");
                    }
                    else
                    {
                        Console.WriteLine("error occurred");
                    }
                    break;

                case 4:
                    Console.WriteLine("enter branch id");
                    branchid = Convert.ToInt32(Console.ReadLine());
                    Branch branch2=branchdal.ViewBranch(branchid);
                    if (branch2!=null)
                    {
                        Console.WriteLine("branch_id: " + branch2.BranchId + "\nbranch address: " + branch2.Address +
                            "\nbranch city: " + branch2.City + "\nbranch name: " + branch2.Name + "\nbranch state: " +
                            branch2.State + "\nbranch zipcode: " + branch2.ZipCode);
                    }

                    break;

                case 5:
                    List<Branch> branchlist = new List<Branch>();
                    
                    branchlist = branchdal.ViewAllBranch();

                    if (branchlist.Count > 0)
                    {
                        foreach (var temp in branchlist)
                        {
                            Console.WriteLine($"{temp.BranchId}\t{temp.Address}\t{temp.City}\t{temp.Name}" +
                                $"\t{temp.State}\t{temp.ZipCode}");
                        }
                    }

                    break;
                default:
                    break;
            }

            Console.ReadLine();
        }
    }
}
