﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //EmpMasterDAL empdal = new EmpMasterDAL();
            //EmpMaster emp = new EmpMaster() { EmpCode=2,EmpName="Merry",EmpDob=Convert.ToDateTime("1980-02-01")
            //,EmpGender="MALE",EmpDepartment="HR",EmpDesignation="Assistant"};
            //if (empdal.SaveEmployee(emp))
            //{
            //    Console.WriteLine("employee information saved");
            //}
            //else
            //{
            //    Console.WriteLine("error occurred");
            //}


            //DepartmentMasterDAL deptdal = new DepartmentMasterDAL();
            //DepartmentMaster dept = new DepartmentMaster() { EmpDepartment = "DEVELOPMENT", EmpDesignation = "TRAINEE ENGINEER" };
            //if (deptdal.SaveDepartment(dept))
            //{
            //    Console.WriteLine("department information saved");
            //}
            //else
            //{
            //    Console.WriteLine("error occurred");
            //}



            //menu driven programme

            EmpMasterDAL empdal = new EmpMasterDAL();
            UserInfoDAL userdal = new UserInfoDAL();
            Console.WriteLine("Please enter login credentials..");
            Console.WriteLine("enter username");
            string username = Console.ReadLine();
            Console.WriteLine("enter password");
            string password = Console.ReadLine();

            
            bool result = userdal.IsValidUser(username, password);
            if (result)
            {
                Console.WriteLine("1 insert employee\n2 delete employee\n3 update employee\n4 view emploee");
                Console.WriteLine("enter your choice");
                int choice = Convert.ToInt32(Console.ReadLine());

                #region EmployeeOperations

                
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("enter employee information to be saved");
                        Console.WriteLine("enter employee code");
                        int empcode = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter employee name");
                        string empname = Console.ReadLine();
                        Console.WriteLine("enter employee DOB");
                        DateTime empdob = Convert.ToDateTime(Console.ReadLine());
                        Console.WriteLine("enter employee gender");
                        string empgender = Console.ReadLine();
                        Console.WriteLine("enter employee department");
                        string empdept = Console.ReadLine();
                        Console.WriteLine("enter employee designation");
                        string empdesign = Console.ReadLine();

                        EmpMaster emp = new EmpMaster()
                        {
                            EmpCode = empcode,
                            EmpName = empname,
                            EmpDob = empdob,
                            EmpGender = empgender,
                            EmpDepartment = empdept,
                            EmpDesignation = empdesign
                        };

                        if (empdal.SaveEmployee(emp))
                        {
                            Console.WriteLine("employee information saved");
                        }
                        else
                        {
                            Console.WriteLine("error occurred");
                        }
                        break;

                    case 2:
                        Console.WriteLine("enter employee code to delete record");
                        empcode = Convert.ToInt32(Console.ReadLine());
                        if (empdal.DeleteEmployee(empcode))
                        {
                            Console.WriteLine("employee deleted successfully");
                        }
                        else
                        {
                            Console.WriteLine("error occurred");
                        }

                        break;

                    case 3:
                        Console.WriteLine("enter employee code to update its record");
                        empcode = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter values to be updated");
                        Console.WriteLine("enter employee name");
                        empname = Console.ReadLine();
                        Console.WriteLine("enter employee DOB");
                        empdob = Convert.ToDateTime(Console.ReadLine());
                        Console.WriteLine("enter employee gender");
                        empgender = Console.ReadLine();
                        Console.WriteLine("enter employee department");
                        empdept = Console.ReadLine();
                        Console.WriteLine("enter employee designation");
                        empdesign = Console.ReadLine();

                        emp = new EmpMaster()
                        {
                            EmpCode = empcode,
                            EmpName = empname,
                            EmpDob = empdob,
                            EmpGender = empgender,
                            EmpDepartment = empdept,
                            EmpDesignation = empdesign
                        };

                        if (empdal.UpdateEmployee(emp))
                        {
                            Console.WriteLine("employee information updated!");
                        }
                        else
                        {

                            Console.WriteLine("error occurred");
                        }
                        break;

                    case 4:
                        Console.WriteLine("enter employee code to view its information");
                        empcode = Convert.ToInt32(Console.ReadLine());
                        emp = empdal.ViewEmployee(empcode);
                        if (emp != null)
                        {
                            Console.WriteLine($"emp code: {emp.EmpCode}\nemp name: {emp.EmpName}\n" +
                                $"emp gender: {emp.EmpGender}\nemp DOB: {emp.EmpDob.ToString("dd-MMM-yyyy")}\n" +
                                $"emp Department: {emp.EmpDepartment}\nemp Designation: {emp.EmpDesignation}");
                        }
                        break;

                    default:
                        break;
                }
                #endregion
            }
            else
            {
                Console.WriteLine("invalid username or password");
            }

            
            



            Console.ReadLine();
        }
    }
}
