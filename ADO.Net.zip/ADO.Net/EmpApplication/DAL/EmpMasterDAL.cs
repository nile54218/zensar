﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using System.Data;
namespace EmpApplication.DAL
{
    class EmpMasterDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        
        public bool SaveEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "insert into EmpMaster values(" + emp.EmpCode + ",'" + emp.EmpName + "','" + emp.EmpDob +
                //    "','" + emp.EmpGender + "','" + emp.EmpDepartment + "','" + emp.EmpDesignation + "')";

                cmd.CommandText = "SaveEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = emp.EmpCode;
                cmd.Parameters.Add("@EmpName", SqlDbType.NVarChar).Value = emp.EmpName;
                cmd.Parameters.Add("@EmpDob", SqlDbType.DateTime).Value = emp.EmpDob;
                cmd.Parameters.Add("@EmpGender", SqlDbType.NVarChar).Value = emp.EmpGender;
                cmd.Parameters.Add("@EmpDepartment", SqlDbType.NVarChar).Value = emp.EmpDepartment;
                cmd.Parameters.Add("@EmpDesignation", SqlDbType.NVarChar).Value = emp.EmpDesignation;


                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public bool DeleteEmployee(int empcode)
        {
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "Delete from EmpMaster where EmpCode=" + empcode + " ";

                cmd.CommandText = "DeleteEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = empcode;


                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
                
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public bool UpdateEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "update EmpMaster set EmpName='"+ emp.EmpName +
                //    "',EmpDob='" + emp.EmpDob + "',EmpDepartment='" + emp.EmpDepartment + "',EmpGender='" +
                //    emp.EmpGender + "',EmpDesignation='" + emp.EmpDesignation + "' where EmpCode="+emp.EmpCode+" ";


                cmd.CommandText = "UpdateEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = emp.EmpCode;
                cmd.Parameters.Add("@EmpName", SqlDbType.NVarChar).Value = emp.EmpName;
                cmd.Parameters.Add("@EmpDob", SqlDbType.DateTime).Value = emp.EmpDob;
                cmd.Parameters.Add("@EmpGender", SqlDbType.NVarChar).Value = emp.EmpGender;
                cmd.Parameters.Add("@EmpDepartment", SqlDbType.NVarChar).Value = emp.EmpDepartment;
                cmd.Parameters.Add("@EmpDesignation", SqlDbType.NVarChar).Value = emp.EmpDesignation;

                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public EmpMaster ViewEmployee(int empcode)
        {
            EmpMaster emp = new EmpMaster();
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "select * from EmpMaster where EmpCode=" + empcode + " ";

                cmd.CommandText = "ViewEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = empcode;

                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    emp.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.EmpDob = Convert.ToDateTime(dr["EmpDob"]);
                    emp.EmpGender = dr["EmpGender"].ToString();
                    emp.EmpDepartment = dr["EmpDepartment"].ToString();
                    emp.EmpDesignation = dr["EmpDesignation"].ToString();
                    
                }
                
                return emp;
            }
            catch (SqlException ex)
            {

                return emp;
            }
            finally
            {
                sqlcon.Close();
            }
        }



        public List<EmpMaster> ViewAllEmployees()
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "Select * from EmpMaster";

                cmd.CommandText = "ViewAllEmployees";
                cmd.CommandType = CommandType.StoredProcedure;
                
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        EmpMaster emp = new EmpMaster();
                        emp.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                        emp.EmpName = dr["EmpName"].ToString();
                        emp.EmpDob = Convert.ToDateTime(dr["EmpDob"]);
                        emp.EmpGender = dr["EmpGender"].ToString();
                        emp.EmpDepartment = dr["EmpDepartment"].ToString();
                        emp.EmpDesignation = dr["EmpDesignation"].ToString();
                        emplist.Add(emp);
                    }
                }
                dr.Close();
                return emplist;
            }
            catch (Exception ex)
            {

                return emplist;
            }
            finally
            {
                sqlcon.Close();
            }
        }



        public int AutoEmpCode()
        {
            int empcode = 1;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select MAX(EmpCode) from EmpMaster";

                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                empcode = Convert.ToInt32(cmd.ExecuteScalar());
                empcode++;
                return empcode;
            }
            catch (SqlException ex)
            {

                return empcode;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
