﻿using System;
using System.Data;
using System.Data.SqlClient;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication.DAL
{
    class SalaryInfoDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public bool SaveSalaryInfo(SalaryInfo salinfo)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "insert into SalaryInfo values(" + salinfo.EmpCode + ",'" + salinfo.DateOfSalary + "'," + salinfo.Basic +
                    "," + salinfo.Hra + "," + salinfo.Da + ")";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public bool DeleteSalaryInfo(int sheetno)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Delete from SalaryInfo where SalarySheetNo=" + sheetno + " ";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }


        public bool UpdateSalaryInfo(SalaryInfo salinfo)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "update SalaryInfo set EmpCode=" + salinfo.EmpCode +
                    ",DateOfSalary='" + salinfo.DateOfSalary + "',Basic=" + salinfo.Basic + ",Hra=" +
                    salinfo.Hra + ",Da=" + salinfo.Da + " where SalarySheetNo=" + salinfo.SalarySheetNo + " ";

                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }




        public SalaryInfo ViewSalarySheet(int sheetno)
        {
            SalaryInfo salarysheet= new SalaryInfo();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from SalaryInfo where SalarySheetNo=" + sheetno + " ";

                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    salarysheet.SalarySheetNo = Convert.ToInt32(dr["SalarySheetNo"]);
                    salarysheet.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                    salarysheet.DateOfSalary = Convert.ToDateTime(dr["DateOfSalary"]);
                    salarysheet.Basic = Convert.ToInt32(dr["Basic"]);
                    salarysheet.Hra = Convert.ToInt32(dr["EmpGender"]);
                    salarysheet.Da = Convert.ToInt32(dr["Da"]);

                }

                return salarysheet;
            }
            catch (SqlException ex)
            {

                return salarysheet;
            }
            finally
            {
                sqlcon.Close();
            }
        }





    }
}
