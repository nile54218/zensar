﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication.DAL
{
    class SalaryInfoDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public int SaveSalaryInfo(SalaryInfo salinfo)
        {
            //try
            //{
            //    cmd.Connection = sqlcon;
            //    cmd.CommandText = "insert into SalaryInfo (EmpCode,DateOfSalary,Basic,Hra,Da) values("+salinfo.EmpCode + ",'" + salinfo.DateOfSalary + "'," + salinfo.Basic +
            //        "," + salinfo.Hra + "," + salinfo.Da + ")";
            //    if (sqlcon.State == ConnectionState.Closed)
            //    {
            //        sqlcon.Open();
            //    }
            //    cmd.ExecuteNonQuery();
            //    return true;
            //}
            //catch (SqlException ex)
            //{

            //    return false;
            //}
            //finally
            //{
            //    sqlcon.Close();
            //}

            // stored procedure way
            int No=0;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "SaveSalary";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = salinfo.EmpCode;
                cmd.Parameters.Add("@DateOfSalary", SqlDbType.DateTime).Value = salinfo.DateOfSalary;
                cmd.Parameters.Add("@Basic", SqlDbType.Decimal).Value = salinfo.Basic;
                cmd.Parameters.Add("@Hra", SqlDbType.Int).Value = salinfo.Hra;
                cmd.Parameters.Add("@Da", SqlDbType.Int).Value = salinfo.Da;
                cmd.Parameters.Add("@SalarySheetNo", SqlDbType.Int).Direction = ParameterDirection.Output;
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                No = Convert.ToInt32(cmd.Parameters["@SalarySheetNo"].Value);
                return No;
            }
            catch (SqlException ex)
            {

                return No;
            }
        }


        public bool DeleteSalaryInfo(int sheetno)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Delete from SalaryInfo where SalarySheetNo=" + sheetno + " ";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;

            }
            finally
            {
                sqlcon.Close();
            }
        }


        public bool UpdateSalaryInfo(SalaryInfo salinfo)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "update SalaryInfo set EmpCode=" + salinfo.EmpCode +",DateOfSalary='" + salinfo.DateOfSalary + "',Basic=" + salinfo.Basic + ",Hra=" +salinfo.Hra + ",Da=" + salinfo.Da + " where SalarySheetNo=" + salinfo.SalarySheetNo + " ";

                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {

                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }




        public SalaryInfo ViewSalarySheet(int sheetno)
        {
            SalaryInfo salarysheet= new SalaryInfo();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from SalaryInfo where SalarySheetNo=" + sheetno + " ";

                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    salarysheet.SalarySheetNo = Convert.ToInt32(dr["SalarySheetNo"]);
                    salarysheet.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                    salarysheet.DateOfSalary = Convert.ToDateTime(dr["DateOfSalary"]);
                    salarysheet.Basic = Convert.ToDouble(dr["Basic"]);
                    salarysheet.Hra = Convert.ToDouble(dr["Hra"]);
                    salarysheet.Da = Convert.ToDouble(dr["Da"]);
                    salarysheet.NetSalary = Convert.ToDouble(dr["NetSalary"]);
                }

                return salarysheet;
            }
            catch (SqlException ex)
            {

                return salarysheet;
            }
            finally
            {
                sqlcon.Close();
            }
        }


        public List<SalaryInfo> ViewAllSalaryInfo()
        {
            List<SalaryInfo> salarylist = new List<SalaryInfo>();

            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Select * from SalaryInfo";
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        SalaryInfo salarysheet = new SalaryInfo();
                        salarysheet.SalarySheetNo = Convert.ToInt32(dr["SalarySheetNo"]);
                        salarysheet.EmpCode = Convert.ToInt32(dr["EmpCode"]);
                        salarysheet.DateOfSalary = Convert.ToDateTime(dr["DateOfSalary"]);
                        salarysheet.Basic = Convert.ToDouble(dr["Basic"]);
                        salarysheet.Hra = Convert.ToDouble(dr["Hra"]);
                        salarysheet.Da = Convert.ToDouble(dr["Da"]);
                        salarysheet.NetSalary = Convert.ToDouble(dr["NetSalary"]);
                        
                        salarylist.Add(salarysheet);
                    }
                }

                dr.Close();
                return salarylist;
            }
            catch (Exception ex)
            {

                return salarylist;
            }
        }



        public int TotalSalarySheet(int empcode)
        {
            int totalcount=0;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select count(*) from SalaryInfo where EmpCode=" + empcode + " ";
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                totalcount=Convert.ToInt32(cmd.ExecuteScalar());
                return totalcount;
            }
            catch (Exception ex)
            {

                Console.WriteLine("invalid empcode");
                return totalcount;
            }
        }



        public int TotalBasic(int empcode)
        {
            int totalbasic = 0;

            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "TotalBasicSalary";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = empcode;
                cmd.Parameters.Add("@TotalBasic", SqlDbType.Int).Direction = ParameterDirection.Output;
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                totalbasic = Convert.ToInt32(cmd.Parameters["@TotalBasic"].Value);
                return totalbasic;
            }
            catch (SqlException ex)
            {

                return totalbasic;
            }
        }
    }
}
