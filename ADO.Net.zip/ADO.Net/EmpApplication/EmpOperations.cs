﻿using System;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using EmpApplication.DAL;
using System.Data;

namespace EmpApplication
{
    class EmpOperations
    {
        static void Main(string[] args)
        {

            EmpMasterDAL empdal = new EmpMasterDAL();
            Console.WriteLine("enter employee code to delete record");
            int empcode = Convert.ToInt32(Console.ReadLine());

            if (empdal.DeleteEmployee(empcode))
            {
                Console.WriteLine("employee deleted successfully");
            }
            else
            {
                Console.WriteLine("error occurred");
            }

            Console.ReadLine();
        }
    }
}
