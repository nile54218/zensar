﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Class9
    {
        
        static void Main(string[] args)
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            EmpMasterDAL empdal = new EmpMasterDAL();
            

            Console.WriteLine("---------------------All-------------------------");
            List<SalaryInfo> salarylist = new List<SalaryInfo>();
            SalaryInfoDAL saldal = new SalaryInfoDAL();
            salarylist = saldal.ViewAllSalaryInfo();
            bool Isallbybasic = salarylist.All(s => s.Basic >= 30000 && s.Hra > 500);
            Console.WriteLine($"is all employees has basic >= 80000 {Isallbybasic}");
            Console.WriteLine("---------------------Any-------------------------");
            Isallbybasic = salarylist.Any(s => s.Basic >= 30000);
            Console.WriteLine($"is any employees has basic >= 80000 {Isallbybasic}");

            double avgbybasic = salarylist.Average(s=>s.Basic);
            int[] nums = { 10, 20, 30, 40 };
            double intavg = nums.Average();
            Console.WriteLine($"average by basic: {avgbybasic}");

            Console.WriteLine("------------showing salary count on condition--------------");
            double salcount = salarylist.Count(s=>s.Basic > 50000);
            Console.WriteLine($"count of salary: {salcount}");

            Console.WriteLine("----------showing distict salary count------------------");
            double distcount = salarylist.Distinct().Count(s=>s.Basic==10000);
            Console.WriteLine($"distict count: {distcount}");

            Console.WriteLine("-----------max salary-------------");
            double maxbasic = salarylist.Max(s => s.Basic);
            Console.WriteLine($"max of basic: {maxbasic}");

            Console.WriteLine("-----------first record------------");
            var first = salarylist.First(s=>s.Basic >= 10000);
            Console.WriteLine($"{first.EmpCode}\t{first.Basic}\t{first.Hra}\t{first.Da}\t{first.NetSalary}");
            first = salarylist.FirstOrDefault(s => s.Basic == 10000);
            Console.WriteLine($"{first.EmpCode}\t{first.Basic}\t{first.Hra}\t{first.Da}\t{first.NetSalary}");
            Console.WriteLine("-----------last record------------");
            var last = salarylist.Last(s => s.EmpCode == 1);
            Console.WriteLine($"{last.SalarySheetNo}\t{last.EmpCode}\t{last.Basic}\t{last.Hra}\t{last.Da}\t{last.NetSalary}");
            Console.WriteLine("-----------element at record------------");
            var elementat = salarylist.ElementAt(2);
            Console.WriteLine($"{elementat.SalarySheetNo}\t{elementat.EmpCode}\t{elementat.Basic}\t{elementat.Hra}" +
                $"\t{elementat.Da}\t{elementat.NetSalary}");

            Console.WriteLine("------------Range----------------");
            var range = Enumerable.Range(0,3);
            Console.WriteLine($"Total count: {range.Count()}");
            for (int i = 0; i < range.Count(); i++)
            {
                Console.WriteLine($"Value at index {i} : {range.ElementAt(i)}");
            }


            Console.WriteLine("-------------Except---------------");
            string[] str1 = { "one", "two", "three", "four" };
            string[] str2 = { "one", "two" };

            var exceptresult = str1.Except(str2);
            foreach (var v in exceptresult)
            {
                Console.WriteLine($"{v}");
            }

            Console.WriteLine("----------Intersected records------------");
            var intersect = str1.Intersect(str2);
            foreach (var v in intersect)
            {
                Console.WriteLine($"{v}");
            }

            Console.WriteLine("----------Union records------------");
            var union = str1.Union(str2);
            foreach (var v in union)
            {
                Console.WriteLine($"{v}");
            }

            

            Console.ReadLine();
        }
    }
}
