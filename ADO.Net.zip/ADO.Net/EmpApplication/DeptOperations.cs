﻿using System;
using EmpApplication.DAL;
using EmpApplication.EntityModel;
using System.Data;

namespace EmpApplication
{
    class DeptOperations
    {
        static void Main(string[] args)
        {

            Console.ReadLine();
        }
    }
}
