﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace EmpApplication
{
    class Class2
    {
        static void Main(string[] args)
        {
            DataSet ds = new DataSet("Employee Information");
            DataTable dt = new DataTable("Emp");
            DataTable dt1 = new DataTable("Salary");

            #region DataColumns
            DataColumn dc1 = new DataColumn("EmpCode", typeof(int));
            DataColumn dc2 = new DataColumn("EmpName", typeof(string));
            DataColumn dc3 = new DataColumn("Email", typeof(string));
            
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);
            dt.PrimaryKey = new DataColumn[] { dc1 };
            UniqueConstraint unique = new UniqueConstraint(dc3);
            dt.Constraints.Add(unique);
            #endregion

            ds.Tables.Add(dt);

            #region DataRows
            DataRow dtr1 = dt.NewRow();
            dtr1["EmpCode"] = 100;
            dtr1["EmpName"] = "Scott";
            dtr1["Email"] = "scott@gmail.com";
            dt.Rows.Add(dtr1);
            DataRow dtr2 = dt.NewRow();
            dtr2["EmpCode"] = 100;
            dtr2["EmpName"] = "Scott";
            dtr2["Email"] = "scott@gmail.com";
            dt.Rows.Add(dtr2);
            #endregion
            Console.WriteLine("Dataset has been created");

            foreach (DataRow row in dt.Rows)
            {
                Console.WriteLine($"{row["EmpCode"]}\t{row["EmpName"]}\t{row["Email"]}");
            }
            Console.ReadLine();
        }
    }
}
