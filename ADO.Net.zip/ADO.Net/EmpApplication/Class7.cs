﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Class7
    {
        static void Main(string[] args)
        {
            List<Student> studentlist = new List<Student>()
            {
                new Student(){StudentID=1,StudentName="john",Age=13},
                new Student(){StudentID=2,StudentName="moin",Age=21},
                new Student(){StudentID=3,StudentName="bill",Age=18},
                new Student(){StudentID=4,StudentName="ram",Age=20},
                new Student(){StudentID=5,StudentName="ron",Age=15}

            };

            var result = from s in studentlist where s.Age >= 20 select s;

            Console.WriteLine("All students having age >= 20");
            foreach (var v in result)
            {
                Console.WriteLine($"{v.StudentID}\t {v.StudentName}");
            }

            Console.WriteLine("John's information..");
            result = from s in studentlist where s.StudentName == "john" select s;
            foreach (var v in result)
            {
                Console.WriteLine($"{v.StudentID}\t {v.StudentName}");
            }


            EmpMasterDAL empdal = new EmpMasterDAL();
            List<EmpMaster> emplist = new List<EmpMaster>();

            emplist=empdal.ViewAllEmployees();

            var result1 = from s in emplist where s.EmpDepartment == "sales" select new { s.EmpCode,s.EmpName};
            Console.WriteLine("employees of sales department..");
            foreach (var v in result1)
            {
                Console.WriteLine($"{v.EmpCode}\t {v.EmpName}");
            }

            Console.WriteLine("--------------------------------------------------------");
            var resultbyteorder = from s in emplist orderby s.EmpGender select s;
            foreach (var v in resultbyteorder)
            {
                Console.WriteLine($"{v.EmpCode}\t{v.EmpName}\t{v.EmpGender}");
            }


            Console.WriteLine("-----------------------order by---------------------------------");
            resultbyteorder = from s in emplist orderby s.EmpCode descending select s;
            foreach (var v in resultbyteorder)
            {
                Console.WriteLine($"{v.EmpCode}\t{v.EmpName}\t{v.EmpGender}");
            }
            Console.ReadLine();
        }
    }
}
