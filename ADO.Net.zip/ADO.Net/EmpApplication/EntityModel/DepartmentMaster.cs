﻿using System;


namespace EmpApplication.EntityModel
{
    class DepartmentMaster
    {
        public string EmpDepartment { get; set; }
        public string EmpDesignation { get; set; }
    }
}
