﻿using System;
using System.Data;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class SalaryOperations
    {
        static void Main(string[] args)
        {
            SalaryInfoDAL salarydal = new SalaryInfoDAL();
            UserInfoDAL userdal = new UserInfoDAL();
            Console.WriteLine("Please enter login credentials..");
            Console.WriteLine("enter username");
            string username = Console.ReadLine();
            Console.WriteLine("enter password");
            string password = Console.ReadLine();


            bool result = userdal.IsValidUser(username, password);
            if (result)
            {
                Console.WriteLine("1 insert salarysheet\n2 delete salarysheet\n3 update salarysheet\n4 view salarysheet\n5 to view total salarysheets of employee\n6 get total basic salary of employee");
                Console.WriteLine("enter your choice");
                int choice = Convert.ToInt32(Console.ReadLine());

                #region SalaryOperations


                switch (choice)
                {
                    case 1:
                        Console.WriteLine("enter salary information to be saved");
                        
                        Console.WriteLine("enter employee code");
                        int empcode = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter date of salary");
                        
                        DateTime salarydate =Convert.ToDateTime(Console.ReadLine());
                        Console.WriteLine("enter basic salary");
                        double basicsalary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter hra salary");
                        double hrasalary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter da salary");
                        double dasalary = Convert.ToDouble(Console.ReadLine());

                        SalaryInfo salarysheet = new SalaryInfo()
                        {
                            
                            EmpCode=empcode,
                            DateOfSalary=salarydate,
                            Basic=basicsalary,
                            Hra=hrasalary,
                            Da=dasalary
                        };

                        int No = salarydal.SaveSalaryInfo(salarysheet);
                        Console.WriteLine($"salarysheet No: {No}");

                        //if (salarydal.SaveSalaryInfo(salarysheet))
                        //{
                        //    Console.WriteLine("salarysheet information saved");
                        //}
                        //else
                        //{
                        //    Console.WriteLine("error occurred");
                        //}
                        break;

                    case 2:
                        Console.WriteLine("enter salarysheet no to delete record");
                        int salarysheetno = Convert.ToInt32(Console.ReadLine());
                        if (salarydal.DeleteSalaryInfo(salarysheetno))
                        {
                            Console.WriteLine("salarysheet deleted successfully");
                        }
                        else
                        {
                            Console.WriteLine("error occurred");
                        }

                        break;

                    case 3:
                        Console.WriteLine("enter salarysheet no to update its record");
                        salarysheetno = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter values to be updated");
                        Console.WriteLine("enter employee code");
                        empcode = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter date of salary");
                        salarydate = Convert.ToDateTime(Console.ReadLine());
                        Console.WriteLine("enter basic salary");
                        basicsalary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter hra salary");
                        hrasalary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter da salary");
                        dasalary = Convert.ToDouble(Console.ReadLine());


                        salarysheet = new SalaryInfo()
                        {
                            SalarySheetNo=salarysheetno,
                            EmpCode = empcode,
                            DateOfSalary = salarydate,
                            Basic = basicsalary,
                            Hra = hrasalary,
                            Da = dasalary
                        };

                        if (salarydal.UpdateSalaryInfo(salarysheet))
                        {
                            Console.WriteLine("salarysheet information updated!");
                        }
                        else
                        {

                            Console.WriteLine("error occurred");
                        }
                        break;

                    case 4:
                        Console.WriteLine("enter salarysheet no to view its information");
                        salarysheetno = Convert.ToInt32(Console.ReadLine());
                        salarysheet = salarydal.ViewSalarySheet(salarysheetno);
                        if (salarysheet != null)
                        {
                            Console.WriteLine($"salarysheet no: {salarysheet.SalarySheetNo}\nempcode: {salarysheet.EmpCode}\n" +
                                $"Date of salary: {salarysheet.DateOfSalary.ToString("dd-MMM-yyyy")}\nBASIC salary: {salarysheet.Basic}\n" +
                                $"HRA salary: {salarysheet.Hra}\nDA salary: {salarysheet.Da}\nNet Salary: {salarysheet.NetSalary}");
                        }
                        break;


                    case 5:
                        Console.WriteLine("enter empcode");
                        empcode = Convert.ToInt32(Console.ReadLine());
                        int totalcount=salarydal.TotalSalarySheet(empcode);
                        Console.WriteLine($"total salarysheet count {totalcount}");
                        break;

                    case 6:
                        Console.WriteLine("enter empcode");
                        empcode = Convert.ToInt32(Console.ReadLine());
                        int totalbasic = salarydal.TotalBasic(empcode);
                        Console.WriteLine($"total basic salary {totalbasic}");
                        break;

                    default:
                        break;
                }
                #endregion
            }
            else
            {
                Console.WriteLine("invalid username or password");
            }

            Console.ReadLine();
        }
    }
}
