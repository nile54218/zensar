﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace EmpApplication
{
    class Class5
    {
        static DataSet ds = new DataSet("Student");
        static DataTable studentinfo = new DataTable("StudentInfo");
        static void Main(string[] args)
        {
            CreateStructure();
            AddRows();
            
            int count = studentinfo.Rows.Count;
            Console.WriteLine($"student count is {count}");
            foreach (DataRow row in studentinfo.Rows)
            {
                Console.WriteLine($"{row["rollno"]}\t{row["name"]}");
            }

            //RemoveAllTables();
            CopyDataSet();
            CloneDataSet();
            SaveAsXML();
            GetXML();
            GetXMLSchema();
            Console.ReadLine();
        }

        public static void CreateStructure()
        {
            DataColumn rollno = new DataColumn("RollNo", typeof(int));
            DataColumn name = new DataColumn("Name",typeof(string));
            studentinfo.Columns.Add(rollno);
            studentinfo.Columns.Add(name);
            ds.Tables.Add(studentinfo);
        }

        public static void AddRows()
        {
            DataRow dtr = studentinfo.NewRow();
            dtr["RollNo"] = 1;
            dtr["Name"] = "Scott";
            DataRow dtr1 = studentinfo.NewRow();
            dtr1["RollNo"] = 2;
            dtr1["Name"] = "Tiger";
            studentinfo.Rows.Add(dtr);
            studentinfo.Rows.Add(dtr1);

        }


        public static void RemoveAllTables()
        {
            ds.Reset(); // to remove all data tables
            Console.WriteLine("after resetting dataset");
            int count = studentinfo.Rows.Count;
            Console.WriteLine($"student count is {count}");
            foreach (DataRow row in studentinfo.Rows)
            {
                Console.WriteLine($"{row["rollno"]}\t{row["name"]}");
            }
        }


        public static void CopyDataSet()
        {
            DataSet newds = new DataSet();
            newds = ds.Copy();

            foreach (DataRow row in newds.Tables["studentinfo"].Rows)
            {
                Console.WriteLine($"{row["rollno"]}\t{row["name"]}");
            }
        }


        public static void CloneDataSet()
        {
            DataSet newds1 = new DataSet();
            newds1 = ds.Clone();
        }


        public static void SaveAsXML()
        {
            ds.WriteXml("Student.xml");
            Console.WriteLine("Data Exported into XML file");
        }

        public static void GetXML()
        {
            Console.WriteLine($"{ds.GetXml()}");
        }

        public static void GetXMLSchema()
        {
            Console.WriteLine($"{ds.GetXmlSchema()}");
        }


    }
}
