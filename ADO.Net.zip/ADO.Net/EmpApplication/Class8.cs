﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Class8
    {
        static void Main(string[] args)
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            List<SalaryInfo> salarylist = new List<SalaryInfo>();
            EmpMasterDAL empdal = new EmpMasterDAL();
            SalaryInfoDAL salarydal = new SalaryInfoDAL();

            emplist = empdal.ViewAllEmployees();
            salarylist = salarydal.ViewAllSalaryInfo();

            var result = from emp in emplist
                         join sal in salarylist on emp.EmpCode equals sal.EmpCode
                         select new { emp.EmpCode, emp.EmpName, sal.Basic, sal.Hra, sal.Da, sal.NetSalary };

            Console.WriteLine("EmpCode\tEmpName\tBasic\tHra\tDa\tNetSalary");
            foreach (var v in result)
            {
                Console.WriteLine($"{v.EmpCode}\t{v.EmpName}\t{v.Basic}\t{v.Hra}\t{v.Da}\t{v.NetSalary}");
            }


            Console.WriteLine("-------------------Group By EmpCode---------------------");

            var groupbyresult = from e in salarylist group e by e.EmpCode; //group by empcode

            foreach (var keygroup in groupbyresult)
            {
                Console.WriteLine($"employee code group:{keygroup.Key}");
                foreach (var v in keygroup)
                {
                    Console.WriteLine($"{v.Basic}\t{v.Hra}\t{v.Da}\t{v.NetSalary}");
                }
            }


            Console.WriteLine("-------------------Group By Department---------------------");
            var groupbydept = from e in emplist group e by e.EmpDepartment;

            foreach (var keygroup in groupbydept)
            {
                Console.WriteLine($"department: {keygroup.Key}");
                foreach (var v in keygroup)
                {
                    Console.WriteLine($"{v.EmpCode}\t{v.EmpName}\t{v.EmpDesignation}");
                }
            }


            Console.WriteLine("--------------------group by with joining two table--------------");

            var groupbywithjoins = emplist.GroupJoin(salarylist, e => e.EmpCode, s => s.EmpCode,
                (employees, salaries) => new { employees,salaries});

            foreach (var emp in groupbywithjoins)
            {
                Console.WriteLine($"Employee code is:{emp.employees.EmpCode}\t Name={emp.employees.EmpName}");
                foreach (var sal in emp.salaries)
                {
                    Console.WriteLine($"{sal.Basic}\t{sal.Hra}\t{sal.Da}\t{sal.NetSalary}");
                }
            }


            Console.WriteLine("------------group by departmentmaster inner join empmaster-------------");
            


            Console.ReadLine();

        }
        
        

    }
}
