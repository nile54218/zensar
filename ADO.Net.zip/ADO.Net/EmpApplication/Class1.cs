﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Class1
    {
        static void Main(string[] args)
        {
            EmpMasterDAL1 empdal = new EmpMasterDAL1();
            Console.WriteLine("1 insert\t2 delete\t3 update\t4 view\t5 show employees for dept\t6 show form");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                  #region SaveEmployee

                    
                    EmpMaster emp = new EmpMaster()
                    {
                        EmpCode = 101,
                        EmpName = "Cara",
                        EmpDob = Convert.ToDateTime("1980-02-01"),
                        EmpGender = "female",
                        EmpDepartment = "sales",
                        EmpDesignation = "manager"
                    };

                    if (empdal.SaveEmployee(emp))
                    {
                        Console.WriteLine("employee information saved");
                    }
                    else
                    {
                        Console.WriteLine("error occurred in saving information");
                    }
                    break;
                #endregion

                case 2:
                #region DeleteEmployee

                    
                    Console.WriteLine("enter employee code to delete record");
                    int empcode = Convert.ToInt32(Console.ReadLine());
                    if (empdal.DeleteEmployee(empcode))
                    {
                        Console.WriteLine("employee deleted successfully");
                    }
                    else
                    {
                        Console.WriteLine("error occurred while deleting record");
                    }

                    break;
                #endregion

                case 3:
                    #region UpdateEmployee

                    emp = new EmpMaster()
                    {
                        EmpCode = 100,
                        EmpName = "bill",
                        EmpDob = Convert.ToDateTime("1990-02-01"),
                        EmpGender = "male",
                        EmpDepartment = "sales",
                        EmpDesignation = "exe"
                    };
                    

                    if (empdal.UpdateEmployee(emp))
                    {
                        Console.WriteLine("employee information updated!");
                    }
                    else
                    {
                        Console.WriteLine("error occured while updating record");
                    }

                    break;
                #endregion

                case 4:
                    #region View all employees
                    List<EmpMaster> emplist = empdal.ViewAllEmployees();
                    foreach (var e in emplist)
                    {
                        Console.WriteLine($"{e.EmpCode}\t{e.EmpName}\t{e.EmpDob}\t{e.EmpGender}\t{e.EmpDepartment}" +
                            $"\t{e.EmpDesignation}");
                    }
                    #endregion
                    break;

                case 5:
                    Console.WriteLine("enter department name to show employees");
                    string dept = Console.ReadLine();
                    emplist = new List<EmpMaster>();
                    emplist=empdal.GetEmpForDept(dept);
                    foreach (var e in emplist)
                    {
                        Console.WriteLine($"{e.EmpCode}\t{e.EmpName}\t{e.EmpDob}\t{e.EmpGender}\t{e.EmpDepartment}" +
                            $"\t{e.EmpDesignation}");
                    }
                    break;

                case 6:
                    #region show form
                    FormDataBinding form = new FormDataBinding();
                    form.Show();
                    #endregion
                    break;

                default:
                    break;
            }

            Console.ReadLine();
        }
    }
}
