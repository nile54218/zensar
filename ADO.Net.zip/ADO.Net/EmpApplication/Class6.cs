﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace EmpApplication
{
    class Class6
    {
        static void Main(string[] args)
        {
            IList<string> stringlist = new List<string>()
            {
                "C# Tutorials","VB.NET Tutorials","Learn C++ Tutorials","Java"
            };
            var result = from s in stringlist where s.Contains("Tutorials")select s;

            var result1 = stringlist.Where(s => s.Contains("Tutorial"));

            foreach (var v in result1)
            {
                Console.WriteLine(v);
            }
            Console.ReadLine();
        }
    }
}
