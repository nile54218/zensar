﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;
using System.Data;
using System.Data.SqlClient;

namespace EmpApplication
{
    class SalaryOprDisModel
    {
        static void Main(string[] args)
        {
            List<SalaryInfo> sheetlist = new List<SalaryInfo>();
            SalaryInfoDAL1 saldal = new SalaryInfoDAL1();
            Console.WriteLine("1 show salarysheets");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine("enter employee code");
                    int empcode = Convert.ToInt32(Console.ReadLine());
                    sheetlist=saldal.GetSalarySheets(empcode);
                    foreach (var sheet in sheetlist)
                    {
                        Console.WriteLine($"{sheet.SalarySheetNo}\t{sheet.EmpCode}\t {sheet.DateOfSalary}\t {sheet.Basic}" +
                            $"\t{sheet.Hra}\t{sheet.Da}\t{sheet.NetSalary}");
                    }
                    break;
                default:
                    break;
            }

            Console.ReadLine();
        }
    }
}
