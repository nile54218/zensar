﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataBindingDemo
{
    public partial class Form1 : Form
    {

        SqlConnection sqlcon = new SqlConnection(DataBindingDemo.Properties.Settings.Default.ConStr);
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                ds.Reset();
                da = new SqlDataAdapter("select distinct(EmpDepartment) from DepartmentMaster", sqlcon);
                da.Fill(ds, "dept");
                comboBox1.DataSource = ds.Tables["dept"];
                comboBox1.ValueMember = "EmpDepartment";
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            DataSet ds1 = new DataSet();
            try
            {
                ds1.Reset();
                da = new SqlDataAdapter("Select * from EmpMaster", sqlcon);
                da.Fill(ds1, "emp");
                dataGridView1.DataSource = ds1.Tables["emp"];
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
